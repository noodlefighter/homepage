# LabelPlus

[![Build status](https://ci.appveyor.com/api/projects/status/je7w45o4k90ia411/branch/master?svg=true)](https://ci.appveyor.com/project/sgqy/labelplus/branch/master)

标号器+ 漫画翻译辅助工具. 减少翻译工作交接成本. 导出文本至ps.
A Easy tool for comic translation. Reduce communication costs of translator. Export text to Photoshop..

![img](pic/show.jpg)

-

[Homepage](http://noodlefighter.com/label_plus)

-

[License](http://noodlefighter.com/label_plus/license)
